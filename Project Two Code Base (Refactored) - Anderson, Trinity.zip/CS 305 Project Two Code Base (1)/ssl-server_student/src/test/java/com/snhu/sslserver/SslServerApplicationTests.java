package com.snhu.sslserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import com.snhu.sslserver.SslServerApplication;

@SpringBootTest(classes= {SslServerApplication.class})
class SslServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
